import { useState } from "react";
import { Pressable, Text, View, useWindowDimensions } from "react-native";
import { router } from "expo-router";
import type { ScheduledItem } from "../models/types";
import { useEntryActions } from "../hooks/useEntryActions";
import { entryStatus, entryTarget } from "../presentation/habits";
import { formatTime } from "../utils/dates";
import { colors, ui } from "../theme";
import { Icon, IconBubble, IconButton } from "./ui";
import { HabitActions, ProgressEditor } from "./HabitInteractions";

export function HabitCard({
  item,
  schedule = false,
  onReschedule,
}: {
  item: ScheduledItem;
  schedule?: boolean;
  onReschedule: () => void;
}) {
  const actions = useEntryActions(item);
  const [menu, setMenu] = useState(false),
    [progress, setProgress] = useState(false);
  const { fontScale } = useWindowDimensions();
  const done = item.status === "done",
    skipped = item.status === "skipped";
  const amountGoal = item.habit.goal.type !== "boolean";
  const target = entryTarget(item, actions.busy);
  const primary = (
    <Pressable
      accessibilityRole={amountGoal ? "button" : "checkbox"}
      accessibilityLabel={
        done
          ? `Undo completion for ${item.habit.name}`
          : skipped
            ? `Undo skip for ${item.habit.name}`
            : amountGoal
              ? `Add progress for ${item.habit.name}`
              : `Complete ${item.habit.name}`
      }
      accessibilityState={{
        checked: !amountGoal ? done : undefined,
        disabled: actions.saving || !actions.access.record,
      }}
      disabled={actions.saving || !actions.access.record}
      onPress={() => {
        if (done || skipped) void actions.undo();
        else if (amountGoal) setProgress(true);
        else void actions.done();
      }}
      style={{
        minWidth: amountGoal && !done && !skipped ? 96 : 48,
        minHeight: 48,
        paddingHorizontal: amountGoal && !done && !skipped ? 10 : 0,
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 12,
        borderColor: colors.green,
        borderWidth: amountGoal && !done && !skipped ? 1 : 0,
        opacity: actions.access.record ? 1 : 0.4,
      }}
    >
      {done ? (
        <Icon name="checkmark-circle" size={30} />
      ) : skipped ? (
        <Icon name="arrow-undo-outline" />
      ) : amountGoal ? (
        <Text
          style={{
            color: colors.green,
            fontSize: 13,
            fontWeight: "600",
            textAlign: "center",
          }}
        >
          Add progress
        </Text>
      ) : (
        <Icon name="ellipse-outline" size={30} />
      )}
    </Pressable>
  );
  return (
    <View
      style={{
        borderBottomWidth: 1,
        borderColor: colors.border,
        paddingVertical: 14,
        gap: 10,
      }}
    >
      <View style={[ui.row, { gap: 8, alignItems: "center" }]}>
        <IconBubble name={item.habit.icon} size={36} />
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`Details for ${item.habit.name}${actions.access.hasNote ? ", has note" : ""}`}
          style={[ui.grow, { minHeight: 48, justifyContent: "center", gap: 4 }]}
          onPress={() =>
            router.push({
              pathname: "/habit-details",
              params: { id: item.habitId, date: item.date, entryId: item.id },
            })
          }
        >
          <Text style={[ui.label, { fontSize: 16 }]}>{item.habit.name}</Text>
          <Text style={ui.small}>
            {formatTime(item.time)}
            {amountGoal
              ? ` · ${item.amount}/${target} ${item.habit.goal.unit}`
              : ""}
            {actions.access.hasNote ? " · Note" : ""}
          </Text>
          <View style={[ui.row, { gap: 4, flexWrap: "wrap" }]}>
            {(done ||
              skipped ||
              item.displayStatus === "missed" ||
              actions.access.future) && (
              <Icon
                name={
                  done
                    ? "checkmark-circle-outline"
                    : skipped
                      ? "remove-circle-outline"
                      : actions.access.future
                        ? "time-outline"
                        : "alert-circle-outline"
                }
                size={14}
                color={
                  item.displayStatus === "missed" ? colors.danger : colors.muted
                }
              />
            )}
            <Text
              style={[
                ui.small,
                item.displayStatus === "missed" && { color: colors.danger },
              ]}
            >
              {entryStatus(item, actions.today)}
              {item.rescheduled ? " · Moved" : ""}
              {actions.access.archived ? " · Archived" : ""}
            </Text>
            {schedule && (
              <Icon name="repeat-outline" size={14} color={colors.muted} />
            )}
          </View>
        </Pressable>
        {fontScale <= 1.3 && primary}
        <IconButton
          plain
          name="ellipsis-horizontal"
          label={`Options for ${item.habit.name}`}
          onPress={() => setMenu(true)}
        />
      </View>
      {fontScale > 1.3 && (
        <View style={{ alignItems: "flex-start", marginLeft: 44 }}>
          {primary}
        </View>
      )}
      {menu && (
        <HabitActions
          item={item}
          onClose={() => setMenu(false)}
          onReschedule={onReschedule}
          onProgress={() => setProgress(true)}
        />
      )}
      {progress && (
        <ProgressEditor
          key={item.id}
          item={item}
          onClose={() => setProgress(false)}
        />
      )}
    </View>
  );
}
