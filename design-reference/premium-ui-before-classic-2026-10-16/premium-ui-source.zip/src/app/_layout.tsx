import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { TrackerProvider } from "../state/TrackerProvider";
import { colors } from "../theme";
export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <TrackerProvider>
        <StatusBar style="dark" />
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: colors.background },
          }}
        >
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="habit" />
          <Stack.Screen name="habit-details" />
          <Stack.Screen name="habits" />
          <Stack.Screen name="routines" />
          <Stack.Screen name="routine" />
          <Stack.Screen name="routine-template" />
          <Stack.Screen name="settings" />
          <Stack.Screen name="data-backup" />
          <Stack.Screen name="note" />
          <Stack.Screen name="habit-notes" />
        </Stack>
      </TrackerProvider>
    </SafeAreaProvider>
  );
}
