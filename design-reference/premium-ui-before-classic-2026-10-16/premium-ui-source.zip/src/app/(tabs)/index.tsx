import { useState } from "react";
import { Pressable, Switch, Text, View } from "react-native";
import { router } from "expo-router";
import { Button, Header, Icon, IconButton, Screen } from "../../components/ui";
import { DaySelector } from "../../components/DaySelector";
import { HabitCard } from "../../components/EntryCard";
import { ActionFeedback } from "../../components/ActionFeedback";
import { RescheduleModal } from "../../components/RescheduleModal";
import { WeeklySection } from "../../components/WeeklySection";
import { Sheet } from "../../components/Sheet";
import { useTracker } from "../../state/TrackerProvider";
import { completion, itemsForDate } from "../../domain/progress";
import { splitDay } from "../../presentation/habits";
import type { ScheduledItem } from "../../models/types";
import { colors, ui } from "../../theme";

export default function Today() {
  const { state, selectedDate, setSelectedDate, today, busy, setBusy, saving } =
    useTracker();
  const [reschedule, setReschedule] = useState<ScheduledItem | null>(null);
  const [completedOpen, setCompletedOpen] = useState(false),
    [skippedOpen, setSkippedOpen] = useState(false),
    [options, setOptions] = useState(false);
  const items = itemsForDate(state, selectedDate, today).filter(
    (i) => !i.weekly,
  );
  const groups = splitDay(items);
  const stats = completion(state, [selectedDate], today);
  const cards = (list: ScheduledItem[]) =>
    list.map((item) => (
      <HabitCard
        key={item.id}
        item={item}
        onReschedule={() => setReschedule(item)}
      />
    ));
  return (
    <Screen compact>
      <Header
        title="Today"
        action={
          <IconButton
            plain
            name="settings-outline"
            label="Settings"
            onPress={() => router.push("/settings")}
          />
        }
      />
      <DaySelector
        label="Choose day"
        value={selectedDate}
        onChange={setSelectedDate}
      />
      {selectedDate !== today && (
        <Button
          label="Back to today"
          secondary
          onPress={() => setSelectedDate(today)}
        />
      )}
      <View
        style={{
          backgroundColor: colors.sage,
          padding: 16,
          borderRadius: 16,
          gap: 12,
        }}
      >
        <View style={ui.between}>
          <Text style={[ui.label, ui.grow]}>
            {selectedDate > today
              ? `${items.length} daily habits planned`
              : items.length
                ? `${stats.done} of ${stats.total} daily habits completed`
                : "No daily habits planned"}
          </Text>
          {items.length > 0 && selectedDate <= today && (
            <Text style={[ui.label, { color: colors.green }]}>
              {stats.percent}%
            </Text>
          )}
        </View>
        {items.length > 0 && selectedDate <= today && (
          <View
            accessibilityRole="progressbar"
            accessibilityValue={{ min: 0, max: stats.total, now: stats.done }}
            style={{
              height: 6,
              borderRadius: 3,
              backgroundColor: "#CCD8CB",
              overflow: "hidden",
            }}
          >
            <View
              style={{
                width: `${stats.percent}%`,
                height: 6,
                backgroundColor: colors.green,
              }}
            />
          </View>
        )}
      </View>
      <ActionFeedback />
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Day options"
        onPress={() => setOptions(true)}
        style={[ui.row, { minHeight: 48, alignSelf: "flex-start" }]}
      >
        <Icon
          name="flash-outline"
          size={20}
          color={busy ? colors.amber : colors.muted}
        />
        <Text style={ui.small}>
          Busy day {busy ? "on" : "off"} · Day options
        </Text>
        <Icon name="chevron-down" size={16} />
      </Pressable>
      <View style={{ gap: 4 }}>
        <Text accessibilityRole="header" style={ui.heading}>
          {selectedDate > today ? "Coming up" : "Still to do"}
        </Text>
        {groups.pending.length ? (
          cards(groups.pending)
        ) : (
          <Text style={[ui.subtitle, { paddingVertical: 12 }]}>
            {items.length
              ? "Nothing left here. Completed and skipped habits are below."
              : "A little breathing room. Add a habit or explore your weekly goals."}
          </Text>
        )}
      </View>
      {groups.completed.length > 0 && (
        <View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Completed habits, ${groups.completed.length}`}
            accessibilityState={{ expanded: completedOpen }}
            onPress={() => setCompletedOpen(!completedOpen)}
            style={[ui.between, { minHeight: 56 }]}
          >
            <Text style={ui.heading}>
              Completed · {groups.completed.length}
            </Text>
            <Icon name={completedOpen ? "chevron-up" : "chevron-down"} />
          </Pressable>
          {completedOpen && cards(groups.completed)}
        </View>
      )}
      {groups.skipped.length > 0 && (
        <View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`Skipped habits, ${groups.skipped.length}`}
            accessibilityState={{ expanded: skippedOpen }}
            onPress={() => setSkippedOpen(!skippedOpen)}
            style={[ui.between, { minHeight: 56 }]}
          >
            <Text style={ui.label}>Skipped · {groups.skipped.length}</Text>
            <Icon name={skippedOpen ? "chevron-up" : "chevron-down"} />
          </Pressable>
          {skippedOpen && cards(groups.skipped)}
        </View>
      )}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Your routines"
        onPress={() => router.push("/routines")}
        style={[
          ui.between,
          {
            minHeight: 64,
            paddingVertical: 12,
            borderTopWidth: 1,
            borderBottomWidth: 1,
            borderColor: colors.border,
          },
        ]}
      >
        <View style={[ui.row, ui.grow]}>
          <Icon name="sunny-outline" color={colors.amber} />
          <Text style={ui.label}>Your routines</Text>
        </View>
        <Icon name="chevron-forward" size={20} />
      </Pressable>
      <WeeklySection date={selectedDate} onReschedule={setReschedule} />
      <Button
        label="New habit"
        icon="add"
        onPress={() => router.push("/habit")}
      />
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Manage habits"
        onPress={() => router.push("/habits")}
        style={{
          minHeight: 48,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Text style={ui.small}>Manage habits & archive</Text>
      </Pressable>
      {options && (
        <Sheet title="Day options" onClose={() => setOptions(false)}>
          <Text style={ui.label}>{selectedDate}</Text>
          <View style={ui.between}>
            <View style={ui.grow}>
              <Text style={ui.heading}>Busy day mode</Text>
              <Text style={ui.small}>
                Use smaller goals for this day. Existing progress keeps its
                recorded goal.
              </Text>
            </View>
            <Switch
              accessibilityLabel="Busy day mode"
              disabled={saving}
              value={busy}
              onValueChange={setBusy}
            />
          </View>
          <Button
            label="Done with day options"
            onPress={() => setOptions(false)}
          />
        </Sheet>
      )}
      <RescheduleModal item={reschedule} onClose={() => setReschedule(null)} />
    </Screen>
  );
}
