import { Text, View } from "react-native";
import { useState } from "react";
import { router } from "expo-router";
import { Button, Header, IconBubble, Screen } from "../components/ui";
import { ui } from "../theme";
import { dataFeatureLicenses } from "../content/dataLicenses";

export default function Settings() {
  const [licenses, setLicenses] = useState(false);
  return (
    <Screen>
      <Header back title="Settings" />
      <View style={ui.sageCard}>
        <IconBubble name="save-outline" />
        <Text style={ui.heading}>Your data, in your hands</Text>
        <Text style={ui.body}>
          Keep a copy of your habits, routines, notes and history, or restore an
          earlier backup.
        </Text>
        <Button
          label="Data & Backup"
          icon="folder-open-outline"
          onPress={() => router.push("/data-backup")}
        />
      </View>
      <Text style={ui.small}>Routine App · Offline storage on this device</Text>
      <Button
        label={licenses ? "Hide open-source licenses" : "Open-source licenses"}
        secondary
        onPress={() => setLicenses(!licenses)}
      />
      {licenses && (
        <Text selectable style={ui.small}>
          {dataFeatureLicenses}
        </Text>
      )}
    </Screen>
  );
}
